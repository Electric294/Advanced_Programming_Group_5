﻿HOW TO USE TURTLE PROGRAM TO DRAW BRADLEY LOGO
~~~~~~~~~~~~~~~~~~~~~~~~~

Welcome to Group 5's turtlesim program!

Follow the below directions to command the turtle to draw a Bradley logo:

1. Open a linux terminal
2. Type in “roscore”
3. Open a new terminal
4. Type in “rosrun turtlesim turtlesim_node”
5. Open a new terminal
6. Type in “rosrun draw_bradley3 draw”

When done, follow the below directions to stop the program:

1. Click into the terminal where the draw command was ran and press ctrl+c
2. Click into terminal where turtlesim node was ran and press ctrl+c
3. click into terminal where roscore was ran and press ctrl+c

