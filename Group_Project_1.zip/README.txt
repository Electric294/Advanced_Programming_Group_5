HOW TO USE TURTLE PROGRAM
~~~~~~~~~~~~~~~~~~~~~~~~~

Welcome to Group 5's turtlesim program!

Follow the below directions to start the program.

1. Open a linux terminal
2. Type in “roscore”
3. Open a new terminal
4. Type in “rosrun turtlesim turtlesim_node”
5. Open a new terminal
6. Type in “rosrun my_turtle_package my_first_node.py “ followed by the desired radius.
	i.e. rosrun my_turtle_package my_first_node.py 3.0

When done, follow the below directions to stop the program.

1. Click into the terminal where the python script was ran and press ctrl+c
2. Click into terminal where turtlesim node was ran and press ctrl+c
3. click into terminal where roscore was ran and press ctrl+c


