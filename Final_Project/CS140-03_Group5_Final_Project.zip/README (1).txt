﻿HOW TO NAVIGATE SKID_STEER_BOT TO PROVIDED COORDINATES
~~~~~~~~~~~~~~~~~~~~~~~~~

Welcome to Group 5's final project!

Follow the below directions to spawn the skid_steer_bot in the laboratory world and move it to a provided set of coordinates in the world:

1. Open a linux terminal.
2. Type in “roslaunch skid_steer_bot udacity_world.launch”.
3. Open a new terminal.
4. Type in “roslaunch skid_steer_bot amcl.launch”.
5. Open a new terminal.
6. Type in “rosrun skid_steer_bot app”.

When done, follow the below directions to stop the program:

1. Click into the terminal where the amcl.launch command was ran and press ctrl+c.
2. Click into terminal where udacity_world.launch command was ran and press ctrl+c.
- Note that this will take a moment to close all programs.



